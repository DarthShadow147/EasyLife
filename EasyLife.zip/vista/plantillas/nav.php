<aside>
	<div class="widget">
			<a href="index.php" title="CenterMedicine"><i class="fa fa-camera-retro fa-lg"></i> Easy Life</a>
			<a href="citas.php" title="Citas">Citas</a>
			<a href="medicos.php" title="Medicos">Medicos</a>
			<a href="pacientes.php" title="Pacientes">Pacientes</a>
			<a href="consultorios.php" title="Consultorios">Consultorios</a>
			<a href="especialidades.php" >Especialidades</a>
            <a href="usuarios.php" title="Usuarios">Usuarios</a>
            <a href="#" title="Reportes">Reportes</a>
	</div>
</aside>