	<footer>
				<p>Copyright © 2020 <a target="_blank": href="../index.php" title="Universidad Libertadores">Universidad Libertadores</a></p>
	</footer>