<?php include 'plantillas/header.php'; ?>
	<section class="main">
		<div class="wrapp">
			<?php include 'plantillas/nav.php'; ?>
			
				<article>
					<div class="mensaje">
						<h2>CenterMedicine</h2>
					</div>
						<p><img src="img/doctor (4).png">
						</p><br/><br/>
						<p>Bienvenido a <b>Easy Life</b>! un Sistema de Citas Medicas para  exámenes médicos de ingreso.</p>
						<br/><br/>
						<h3>Nuestras funciones</h3><br/>
						<p>	- Gestion de Citas <br/>
							- Gestion de Medicos <br/>
							- Gestion de Pacientes <br/>
							- Gestion de Consultorios <br/>
							- Gestion de Usuarios con Acceso al Sistema <br/>
						</p>
				</article>
	</section>
	<?php include 'plantillas/footer.php'; ?>
</body>
</html>