<?php include 'plantillas/header.php'; ?>
	</div>
	<section class="main">
		<div class="wrapp">
			<?php include 'plantillas/nav.php'; ?>
				<article>
					<div class="mensaje">
						<h2>PERFIL</h2>
					</div>
						<p>Favor ingrese todos los datos correspondientes a su perfil:
						</p><br />						
				</article>
	</section>
<?php include 'plantillas/footer.php'; ?>
</body>
</html>