<?php
	$mensaje='';
	extract ($_REQUEST);
	try{
		$conexion = new PDO('mysql:host=localhost;dbname=id12836868_bd_easylife','id12836868_admin_easylife','AdminEasyLife123');
	}catch(PDOException $e){
		echo "Error: ". $e->getMessage();
	}
	$sql="DELETE FROM especialidades WHERE idespecialidad = '$_REQUEST[idespecialidad]'";
	$resultado = $conexion->query($sql);

	if($resultado == true){
		header('Location: especialidades.php');
		$mensaje .='Especialidades eliminado correctamente';
	}
?>